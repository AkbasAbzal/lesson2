﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            1.
            /*
            (Console.WriteLine("Enter the lowest temparature");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the higest temparature");
            int b = Convert.ToInt32(Console.ReadLine());
            int sum = (a + b) / 2;
            Console.WriteLine(sum);
            */
            2.
            /*
            Console.WriteLine("Enter the month number");
            int a = Convert.ToInt32(Console.ReadLine());
            bool month = a == 1;
            if (month)
            {
                Console.WriteLine("january");
            }
            bool b = a == 2;
            if (b)
            {
                Console.WriteLine("february");
            }
            bool c = a == 3;
            if (c)
            {
                Console.WriteLine("march");
            }
            bool d = a == 4;
            if (d)
            {
                Console.WriteLine("april");
            }
            bool v = a == 5;
            if (v)
            {
                Console.WriteLine("may");
            }
            bool dg = a == 6;
            if (dg)
            {
                Console.WriteLine("june");
            }
            bool dv = a == 7;
            if (dv)
            {
                Console.WriteLine("july");
            }
            bool da = a == 8;
            if (da)
            {
                Console.WriteLine("august");
            }
            bool net = a == 9;
            if (net)
            {
                Console.WriteLine("september");
            }
            bool zxc = a == 10;
            if (zxc)
            {
                Console.WriteLine("october");
            }
            bool xyz = a == 11;
            if (xyz)
            {
                Console.WriteLine("november");
            }
            bool dt = a == 12;
            if (dt)
            {
                Console.WriteLine("december");
            }
            */
            3.
            /*
            Console.WriteLine("Enter the number");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a % 2 == 0)
            {
                Console.WriteLine("Even number");
            }
            else
            {
                Console.WriteLine("Odd number");
            }
            */
            /*4.
                        Console.WriteLine("________________________________");
            Console.WriteLine("|————23.01.2022———pay check N3--|");
            Console.WriteLine("|-—Cost: 333.00 —————————————---|");
            Console.WriteLine("|_______________________________|");
            */
            5.
                /*
            Console.WriteLine("Enter the lowest temparature");
            int t = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the higest temparature");
            int i = Convert.ToInt32(Console.ReadLine());
            int sum = (t + i) / 2;
            Console.WriteLine("Enter the month number");
            int monthnumber = Convert.ToInt32(Console.ReadLine());
            if (sum > 0 && (monthnumber == 12 || monthnumber == 1 || monthnumber == 2))
            {
                Console.WriteLine("Дождливая зима");
            }
            */
            6.
                /*
            Console.Write("Write the ofice name ");
            int name = Convert.ToInt32(Console.ReadLine());
            if (name == 1)
            {
                Console.WriteLine("работает со вторника до пятницы");
            }
            if (name == 2)
            {
                Console.WriteLine("работает с понедельника до воскресенья");
            }
            */
        }



    }
}
    

